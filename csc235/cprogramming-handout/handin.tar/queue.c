/************************************************************/
/* Contributor: Henry Winkleman 							              */
/* Edit Date: September 1st, 2020 	   						          */
/* Due Date: September 4th, 2020	  				              	*/
/* Course: CSC235-020 										                  */
/* Professor Name: Dr. Schwesinger						              */
/* Assignment: Review								                      	*/
/* Filename: queue.c 							                     	    */
/* Purpose: Stated lower in program.                        */
/************************************************************/
/*
 * Code for basic C skills diagnostic.
 * Developed for courses 15-213/18-213/15-513 by R. E. Bryant, 2017
 */

/*
 * This program implements a queue supporting both FIFO and LIFO
 * operations.
 *
 * It uses a singly-linked list to represent the set of queue elements
 */

#include <stdlib.h>
#include <stdio.h>

#include "harness.h"
#include "queue.h"

/*
  Create empty queue.
  Return NULL if could not allocate space.
*/
queue_t *q_new()
{
    queue_t *q =  malloc(sizeof(queue_t));
    /* What if malloc returns NULL? *///DONE
    if (q!=NULL){ //If list was allocated,
      q->head = NULL;
      q->length = 0;  //List is empty
      q->tail = NULL;
      return q; //Return the list location.
    }
    return NULL;  //Return NULL for failure to allocate.
}

/* Free all storage used by queue */
void q_free(queue_t *q)
{
    /* How about freeing the list elements? *///DONE
    if (q!=NULL){ //If the list exists,
      int *empty=NULL; //Irrelevant int to run remove_head.
      while (q->length!=0){ //While the list is not empty,
        q_remove_head(q, empty);  //Remove the head.
      }
      /* Free queue structure */
      free(q);  //Frees the struct.
    }
}

/*
  Attempt to insert element at head of queue.
  Return true if successful.
  Return false if q is NULL or could not allocate space.
 */
bool q_insert_head(queue_t *q, int v)
{
    list_ele_t *newh; //Holder for data to add to the list.
    /* What should you do if the q is NULL? *///DONE
    if (q!=NULL){ //If list is allocated.
      newh = malloc(sizeof(list_ele_t));  //Allocates for the holder.
      /* What if malloc returned NULL? *///DONE
      if (newh!=NULL){  //If holder is allocated
        newh->value = v;  //Place value in holder.
        newh->next = q->head; //Link holder to the head.
        q->head = newh; //Holder becomes the new head.
        if (q->length==0){  //If first item,
          q->tail = q->head;//Tail is the head too.
        }
        q->length+=1; //Increase count of objects.
        return true;  //Returns success.
      }
    }
    return false; //Returns failure.
}


/*
  Attempt to insert element at tail of queue.
  Return true if successful.
  Return false if q is NULL or could not allocate space.
 */
bool q_insert_tail(queue_t *q, int v)
{
    /* You need to write the complete code for this function *///DONE
    /* Remember: It should operate in O(1) time */
    list_ele_t *newh; //Creates a holder.
    /* What should you do if the q is NULL? *///DONE
    if (q!=NULL){ //If the list is allocated.
      newh = malloc(sizeof(list_ele_t));  //Allocate for the holder.
      /* What if malloc returned NULL? *///DONE
      if (newh!=NULL){  //If holder is allocated,
        newh->value = v;//Place value in holder.
        newh->next = NULL;//Point at nothing since it becomes tail.
        if (q->tail==NULL){ //If there is no tail,
          q->tail=newh; //Becomes tail
          q->head=q->tail;//and head.
        }
        else{ //Assumes there is already a head.
          q->tail->next = newh;//Tail links to holder.
          q->tail = q->tail->next;  //Holder becomes new tail.
        }
        q->length+=1; //Increase length counter.
        return true;  //Return success.
      }
    }
    return false; //Return failure.
}

/*
  Attempt to remove element from head of queue.
  Return true if successful.
  Return false if queue is NULL or empty.
  If vp non-NULL and element removed, store removed value at *vp.
  Any unused storage should be freed
*/
bool q_remove_head(queue_t *q, int *vp)
{
    /* You need to fix up this code. *///DONE
    if (q!=NULL){ //If list is allocated,
      if (q->length>0){  //If the list isn't empty.
        list_ele_t *holder = q->head; //Holds element to be freed.
        q->head = q->head->next;      //Makes head the next item.
        if (vp!=NULL){  //If storage isn't NULL,
          *vp = holder->value;  //Place held value in storage.
        }
        free(holder); //Free held element.
        q->length-=1; //Decrease length.
        return true;  //Return success.
      }
    }
    return false; //Returns failure.
}

/*
  Return number of elements in queue.
  Return 0 if q is NULL or empty
 */
int q_size(queue_t *q)
{
    /* You need to write the code for this function *///DONE
    /* Remember: It should operate in O(1) time */
    if (q!=NULL){ //If List is allocated.
      return q->length; //Return length count.
    }
    return 0; //Returns failure or empty.
}

/*
  Reverse elements in queue.

  Your implementation must not allocate or free any elements (e.g., by
  calling q_insert_head or q_remove_head).  Instead, it should modify
  the pointers in the existing data structure.
 */
void q_reverse(queue_t *q)
{
    if (q!=NULL){ //If list is allocated,
      if (q_size(q)>1){ //If the list has more than one element.
        //Creates three holders.
        //Prev for the item to be reversed to, Holder for item that's going
        //to be reversed, Next to keep track of the remaining elements.
        struct ELE *holder, *prevHolder, *nextHolder;
        q->tail=q->head;  //Tail will become the head.
        prevHolder=q->head; //Prev is at the start,
        holder=prevHolder->next;//Holder is after the start.
        prevHolder->next=NULL;  //Makes head element point to NULL like tail.
        while(holder->next!=NULL){//While the list has not been iterated through
          nextHolder=holder->next;//Next keeps track of the remaining list.
          holder->next=prevHolder;//Holder points to left element.
          //Both pointers move right.
          prevHolder=holder;
          holder=nextHolder;
        }
        //For last element.
        holder->next=prevHolder;
        q->head=holder; //Old tail becomes the head.
      }
    }
}
